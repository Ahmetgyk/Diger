ro = 1.225;
d= 2;
A = pi * d^2 *0.25;
Cd = 0.5;
g= 9.81;
m = 19.912;

irtifa = 3000;

Vi = 0;

time = 0;
dt = 0.01;
%step = 0;
while irtifa > 500
   Fd = 0.5*ro*(Vi^2)*Cd*A;
   
   kutle = m * g;
   %F(step) = Fd;
   a= (kutle-Fd)/m;
   v =Vi+  a * dt;
   z = v *dt;
   Vi = v;
   irtifa = irtifa - z;
   time = time +dt;
   %step = step +1; 
   
   
end
disp(v)

