% Mars Rocket 3DoF Model
